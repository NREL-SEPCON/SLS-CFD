# -*- coding: utf-8 -*-
"""
Created on Mon Apr 12 22:19:55 2021

find all stl files in currect dir
find bounding box of all stl files
write to boundingbox file

@author: yli5
"""
import re
import os
import findBoundingBox as fBB
import glob
import pandas as pd
import numpy as np
#%%
# find bounding boxes for all stl files in current dir
filenames = glob.glob('./*.stl')
nstl = len(filenames)

stlbbox = []
for i in range(nstl):
    stlbbox.append(fBB.boundingBox(filenames[i]))
#%% create dataframe for better visualization
npstlBBox=np.array(stlbbox)
BBox=np.array([np.min(npstlBBox[:,0]),\
               np.max(npstlBBox[:,1]),\
               np.min(npstlBBox[:,2]),\
               np.max(npstlBBox[:,3]),\
               np.min(npstlBBox[:,4]),\
               np.max(npstlBBox[:,5])])
AllBBox=np.vstack([npstlBBox,BBox])
dfIndex=["minX", "maxX", "minY", "maxY", "minZ", "maxZ"]
df = pd.DataFrame(AllBBox,index=filenames+['DomainBound'],columns=dfIndex)
df.to_csv('boundingBox.csv',sep=' ')
