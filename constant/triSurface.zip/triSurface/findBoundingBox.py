# -*- coding: utf-8 -*-
"""
Created on Wed Jun  3 23:29:24 2020

Version 2.0

parse stl file get bounding box

@author: yli5
"""
import sys
import os
# Python script to find STL dimensions
# Requrements: sudo pip install numpy-stl

import math
import stl
from stl import mesh
import numpy

"""
import os
import sys

if len(sys.argv) < 2:
    sys.exit('Usage: %s [stl file]' % sys.argv[0])

if not os.path.exists(sys.argv[1]):
    sys.exit('ERROR: file %s was not found!' % sys.argv[1])
"""


# find the max dimensions, so we can know the bounding box, getting the height,
# width, length (because these are the step size)...
def find_mins_maxs(obj):
    minx = maxx = miny = maxy = minz = maxz = None
    for p in obj.points:
        # p contains (x, y, z)
        if minx is None:
            maxx = max(p[0],p[3],p[6]) # each point p has 9 elements, a face defined by three points x1,y1,z1,x2,y2,z2,x3,y3,z3  
            minx = min(p[0],p[3],p[6])
            maxy = max(p[1],p[4],p[7])
            miny = min(p[1],p[4],p[7])
            maxz = max(p[2],p[5],p[8])
            minz = min(p[2],p[5],p[8])
        else:
            maxx = max(p[0],p[3],p[6], maxx)
            minx = min(p[0],p[3],p[6], minx)
            maxy = max(p[1],p[4],p[7], maxy)
            miny = min(p[1],p[4],p[7], miny)
            maxz = max(p[2],p[5],p[8], maxz)
            minz = min(p[2],p[5],p[8], minz)
    return minx, maxx, miny, maxy, minz, maxz

def find_mins_maxs2(obj):
    minx = obj.x.min()
    maxx = obj.x.max()
    miny = obj.y.min()
    maxy = obj.y.max()
    minz = obj.z.min()
    maxz = obj.z.max()
    return minx, maxx, miny, maxy, minz, maxz

def find_centerpoint(obj):
    minx, maxx, miny, maxy, minz, maxz = find_mins_maxs(obj)
    centerX = minx+(maxx-minx)/2
    centerY = miny+(maxy-miny)/2
    centerZ = minz+(maxz-minz)/2
    return centerX, centerY, centerZ
    
#filename='./0.25mm/housing.stl'
#main_body = mesh.Mesh.from_file(filename)
#minx, maxx, miny, maxy, minz, maxz = find_mins_maxs(main_body)
## the logic is easy from there
#print("File:", filename)
#print("X:", maxx - minx)
#print("Y:", maxy - miny)
#print("Z:", maxz - minz)

def boundingBox(filename,printToScreen=True):
    stlMesh = mesh.Mesh.from_file(filename)
    minX, maxX, minY, maxY, minZ, maxZ = find_mins_maxs2(stlMesh)
    meshBoundingbox=[minX, maxX, minY, maxY, minZ, maxZ]
    if printToScreen:
        print(filename, " Mesh Bounding Box : [minx, maxx, miny, maxy, minz, maxz]:\n",meshBoundingbox)
    return meshBoundingbox

    
# =============================================================================
# testing
# =============================================================================
if __name__ == '__main__':
    try:
        arg1=sys.argv[1]
    except IndexError:
        print("Usage: "+os.path.basename(__file__)+ " <stl_filename>")
        sys.exit(1)
    
    boundingBox(arg1)
    

